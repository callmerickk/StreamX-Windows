# StreamX Windows v0.1

First Windows-targeted development baseline for the StreamX TV experience. The project is configured as a WPF desktop application with a local HTML/CSS/JS interface hosted in Microsoft WebView2. The UI is local; no web server is needed.

## v0.1 includes
- Windows desktop shell targeting Windows 10 (19041+) and Windows 11.
- `net8.0-windows` project with x64 and ARM64 publish targets.
- StreamX dark/red visual direction and a startup logo sequence based on the timings and stages in the supplied Android TV `TvStart.kt` / `Startup.kt` source (glow, logo pop, “Stream” slide, red X pop/zoom-out).
- Automatic featured deck cycling every 8 seconds, slide/fade transition, dots and manual arrows.
- Mouse hover and keyboard-focus expansion of portrait cards from 120x180 to 360x180 in 200ms, based on `TvExpandCard`.
- Sidebar, shelves, detail modal, demo search and locally stored demo My List.
- Original Android TV source files and logo vector XML retained under `Reference/AndroidTV` and `Assets` for comparison.

## Important current limitations
This is the first Windows app baseline, not feature parity yet. Playback is not connected; buttons clearly show a preview notice. Add-on discovery/JavaScript execution, user accounts, profiles/cloud sync, real catalog metadata, watch history persistence, subtitle/audio track selection, ExoPlayer/FFmpeg/VLC equivalents, and actual poster/backdrop logo requests still need a platform port and validation. The cards use illustrative CSS artwork instead of real addon metadata. The original Android TV source is preserved for porting, not compiled as part of this Windows project.

## Build requirements
- Windows 10 version 2004/build 19041 or later, or Windows 11.
- .NET 8 SDK (Windows desktop workload/components including WPF).
- Microsoft Edge WebView2 Evergreen Runtime.

## Run from source
Open `StreamX.Windows.csproj` in Visual Studio 2022 on Windows, restore NuGet packages, and run. Or from a Windows Developer PowerShell:

```powershell
dotnet restore .\StreamX.Windows.csproj
dotnet run --project .\StreamX.Windows.csproj
```

## Publish self-contained builds
Run on Windows with .NET 8 SDK:

```powershell
# Intel/AMD x64
dotnet publish .\StreamX.Windows.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -o .\publish\win-x64
# Snapdragon ARM64
dotnet publish .\StreamX.Windows.csproj -c Release -r win-arm64 --self-contained true -p:PublishSingleFile=false -o .\publish\win-arm64
```

These commands create architecture-specific output folders; they are not prebuilt binaries. This development environment is not a Windows build runner, so no claim is made that the executable has been compiled or tested here. Validate both outputs on real Windows x64 and ARM64 devices before distribution.

## Versioning
Assembly and file version are `0.1.0.0`. Keep subsequent iterations incremental and document changes in `CHANGELOG.md`.
