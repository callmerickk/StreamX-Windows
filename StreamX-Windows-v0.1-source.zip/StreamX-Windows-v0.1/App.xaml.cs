namespace StreamX.Windows;
public partial class App : System.Windows.Application { }
